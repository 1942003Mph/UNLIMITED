<?php

namespace App\Http\Controllers\site;

use App\Http\Controllers\Controller;
use App\Mail\ContactMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class FormsController extends Controller
{
    function contact_data(Request $request) {
        Mail::to('admin@gmail.com')->send(new ContactMail());
    }
}
